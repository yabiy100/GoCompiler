import classes.Node;
import classes.NodeType;
import org.antlr.v4.runtime.tree.ParseTree;

import java.util.ArrayList;
import java.util.List;


public class Visitor extends ParserGoBaseVisitor<Node> {
    private Node root = new Node();

    @Override
    public Node visitS(ParserGo.SContext ctx) {
        root.setValue("Start");
        root.setChildren(getFunctions(ctx.getChild(2))); //function
        return root;
    }

    private List<Node> getFunctions(ParseTree child) { //child = function
        List<Node> functions = new ArrayList<>();
        //ParseTree test = child.getChild(0).getChild(1);
        //String testString = child.getChild(0).getChild(1).getText();
        Node function = new Node(child.getChild(0).getChild(1).getText(), NodeType.FUNCTION);
        function.setChildren(visitFunction(child));
        functions.add(function);
        if(child.getChild(7).getChild(0) != null){
            functions.addAll(getFunctions(child.getChild(7)));
        }
        return functions;
    }

    public List<Node> visitFunction(ParseTree child) { //child = function
        Node params = new Node("params");
        if(child.getChild(0).getChild(3).getChild(0) != null) {
            params.setChildren(getParams(child.getChild(0).getChild(3)));
        }
        Node returnType = new Node(child.getChild(0).getChild(5).getText(),getNodetype(child.getChild(0).getChild(5).getText()));
        Node declarations = new Node("declarations");
        declarations.setChildren(getDeclarations(child));
        return List.of(params, returnType, declarations);
    }

    private List<Node> getDeclarations(ParseTree child) { //child = function
        List<Node> declarations = new ArrayList<>();
        ParseTree expr = child.getChild(4).getChild(0).getChild(4);
        if(expr.getChildCount() == 3){
            ParseTree test = child.getChild(4).getChild(0);
            Node ident = new Node(child.getChild(4).getChild(0).getChild(1).getText(), getNodetype(child.getChild(4).getChild(0).getText()));
            Node declaration = new Node(expr.getChild(1).getText(),getNodetype(expr.getChild(1).getText()));
            Node leftchild = getExpression(expr.getChild(0));
            Node rightchild = getExpression(expr.getChild(0));
            declaration.setChildren(List.of(leftchild, rightchild));
            ident.setChildren(List.of(declaration));
            declarations.add(ident);
        }
        return declarations;
    }

    private Node getExpression(ParseTree child) {
        if(child.getChildCount() == 1){
            return new Node(child.getChild(0).getText(), getNodetype(child.getChild(0).getText()));
        }
        ParseTree expr = child.getChild(4).getChild(0).getChild(4);
        Node root = new Node(expr.getChild(1).getText(), getNodetype(expr.getChild(1).getText()));
        Node leftchild = getExpression(expr.getChild(0));
        Node rightchild = getExpression(expr.getChild(0));
        root.setChildren(List.of(leftchild, rightchild));
        return root;
    }

    private List<Node> getParams(ParseTree child) {
        List<Node> params = new ArrayList<>();
        params.add(new Node(child.getChild(0).getText(),getNodetype(child.getChild(1).getText())));
        if(child.getChildCount() == 4){
            params.addAll(getParams(child.getChild(3)));
        }
        return params;
    }

    public Node getRoot() {
        return root;
    }

    public NodeType getNodetype(String text){
        if(isNumeric(text)){
            return NodeType.NUMBER;
        }
        return switch (text) {
            case "-", "+" -> NodeType.NUMBER;
            case "&&", "||", "bool" -> NodeType.BOOL;
            case "int" -> NodeType.INT;
            case "float" -> NodeType.FLOAT;
            case "string" -> NodeType.STRING;
            default -> null;
        };
    }
    //methode von stack overflow
    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }


}
