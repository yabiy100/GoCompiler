package classes;

public enum NodeType {
    INT, FLOAT, STRING, BOOL, OPERATOR, NUMBER, FUNCTION
}
